// Custom Button Widget
// 
// A reusable widget that defines a stylized button used throughout the app. 
// It can be customized with different colors, texts, and actions to fit various UI contexts.
