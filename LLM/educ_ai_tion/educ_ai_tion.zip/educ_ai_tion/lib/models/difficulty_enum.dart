enum Difficulty {
  Easy,
  Intermediate,
  Advanced,
}
