# educ_ai_tion

A new Flutter project.
