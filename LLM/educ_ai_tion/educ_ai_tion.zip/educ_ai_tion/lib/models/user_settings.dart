// User Settings Model
// 
// Contains the configuration preferences of the user. This model stores settings such as preferred themes, 
// notification preferences, and any custom settings related to question generation or app behavior.
