// Test Template Model
// 
// Defines the structure for a test template. This model includes information about the format of the test, sections, 
// and any predefined questions. It can be used to generate or format tests according to specific templates uploaded by the user.
