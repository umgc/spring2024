// Constants Utility
// 
// Stores global constants used throughout the app. This includes API keys, route names, 
//and any other constant values that need to be reused across different parts of the application.
