// Question Card Widget
// 
// Displays information about a generated question in a card format. It includes the question text, possible answers, 
// and any relevant actions such as editing or deleting the question. Designed for use in lists or grids of questions.
