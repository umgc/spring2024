package com.example.educ_ai_tion

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
